#ifndef UNISTD_H_INCLUDED
#define UNISTD_H_INCLUDED

#include <io.h>
#include <direct.h>

typedef short int16_t;
typedef short size16;
#define inline 

#endif

