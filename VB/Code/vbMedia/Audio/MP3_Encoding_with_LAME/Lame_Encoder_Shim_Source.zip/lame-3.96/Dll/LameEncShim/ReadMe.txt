========================================================================
       DYNAMIC LINK LIBRARY : LameEncShim
========================================================================


This provides a wrapper around the lame_enc.dll to enable it be
called from Visual Basic (or other languages which cannot make calls
to CDECL type DLL exports) under Win32.

Author: Steve McMahon (steve@vbaccelerator.com)
Website: http://vbaccelerator.com/
Date: 25 April 2004

Credits: Jon F. Zahornacky (jonzeke@yahoo.com) for ASPIShim from
which this was derived.