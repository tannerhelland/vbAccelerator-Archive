/*
========================================================================
       DYNAMIC LINK LIBRARY : LameEncShim
========================================================================


This provides a wrapper around the lame_enc.dll to enable it be
called from Visual Basic (or other languages which cannot make calls
to CDECL type DLL exports) under Win32.

Author: Steve McMahon (steve@vbaccelerator.com)
Website: http://vbaccelerator.com/
Date: 25 April 2004

Credits: Jon F. Zahornacky (jonzeke@yahoo.com) for ASPIShim from
which this was derived.
*/

#define STRICT
#include <windows.h>
#include "BladeMP3EncDll.h"

// This DLL and the Lame encoder's instance
HINSTANCE hInstLame = 0;

DWORD (*pfn_beInitStream) (PBE_CONFIG, PDWORD, PDWORD, PHBE_STREAM);
DWORD (*pfn_beCloseStream) (HBE_STREAM);
DWORD (*pfn_beEncodeChunk) (HBE_STREAM, DWORD, PSHORT, PBYTE, PDWORD);
DWORD (*pfn_beDeinitStream) (HBE_STREAM, PBYTE, PDWORD);
DWORD (*pfn_beWriteInfoTag) (HBE_STREAM, LPCSTR);
DWORD (*pfn_beWriteVBRHeader) (LPCSTR);
DWORD (*pfn_beVersion) (PBE_VERSION);

// Main Entry Point For DLL
BOOL WINAPI DllMain (HINSTANCE hInstA, DWORD dwReason, LPVOID lpvReserved)
{
	switch (dwReason)
	{
		// dll is being loaded
		case DLL_PROCESS_ATTACH:			
			// only load LAME_ENC lib once
			if (!hInstLame)
			{
				// attach LAME_ENC
				hInstLame = LoadLibrary("LAME_ENC");
				if (hInstLame)
				{
					// Store address for ASPI calls
					(FARPROC)pfn_beInitStream  = GetProcAddress(hInstLame, "beInitStream");
					(FARPROC)pfn_beCloseStream = GetProcAddress(hInstLame, "beCloseStream");
					(FARPROC)pfn_beEncodeChunk = GetProcAddress(hInstLame, "beEncodeChunk");
					(FARPROC)pfn_beDeinitStream = GetProcAddress(hInstLame, "beDeinitStream");
					(FARPROC)pfn_beWriteInfoTag = GetProcAddress(hInstLame, "beWriteInfoTag");
					(FARPROC)pfn_beWriteVBRHeader = GetProcAddress(hInstLame, "beWriteVBRHeader");
					(FARPROC)pfn_beVersion = GetProcAddress(hInstLame, "beVersion");
				}
			}
			break;

		// thread create
		case DLL_THREAD_ATTACH:
			break;

		// thread exiting (cleanly)
		case DLL_THREAD_DETACH:
			break;

		// dll is being	free'd
		case DLL_PROCESS_DETACH:
			FreeLibrary(hInstLame);
			hInstLame = 0;
			break;
	} // switch

	// always load
	return TRUE;
}

BE_ERR __stdcall beInitStream(PBE_CONFIG pbeConfig, PDWORD dwSamples, PDWORD dwBufferSize, PHBE_STREAM phbeStream)
{
	return pfn_beInitStream(pbeConfig, dwSamples, dwBufferSize, phbeStream);
}

BE_ERR __stdcall beEncodeChunk(HBE_STREAM hbeStream, DWORD nSamples, PSHORT pSamples, PBYTE pOutput, PDWORD pdwOutput)
{
	return pfn_beEncodeChunk(hbeStream, nSamples, pSamples, pOutput, pdwOutput);
}

BE_ERR __stdcall beCloseStream(HBE_STREAM hbeStream)
{
	return pfn_beCloseStream(hbeStream);
}

BE_ERR __stdcall beDeinitStream(HBE_STREAM hbeStream, PBYTE pOutput, PDWORD pdwOutput)
{
	return pfn_beDeinitStream(hbeStream, pOutput, pdwOutput);
}

BE_ERR	__stdcall beWriteVBRHeader(LPCSTR lpszFileName)
{
	return pfn_beWriteVBRHeader(lpszFileName);
}

BE_ERR __stdcall beWriteInfoTag(HBE_STREAM hbeStream, LPCSTR lpszFileName)
{
	return pfn_beWriteInfoTag(hbeStream, lpszFileName);
}

BE_ERR __stdcall beVersion(PBE_VERSION pbeVersion)
{
	return pfn_beVersion(pbeVersion);
}
