/* 
File:	WinAmpSndStream.h

Based on ISndStreamWinAmp.h by Albert L Faber

   Copyright Albert L Faber (c) 2001

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#pragma once

extern "C"
{
	#include "in2.h"
}

typedef struct WINAMPPLUGINPROP_TAG
{
	CString		strExt;
	CString		strFileName;
	HINSTANCE	hDll;
	In_Module*	pModule;

}	WINAMPPLUGINPROP;


class WinAmpSndStream
{
	DWORD				m_dwSamples;
	WINAMPPLUGINPROP	m_WinAmpProp;

public:
	enum SNDSTREAMTYPES {SNDSTREAM_WAV,SNDSTREAM_CD,SNDSTREAM_ADPCM,SNDSTREAM_MPEG, SNDSTREAM_OGG, SNDSTREAM_WMA };

	WinAmpSndStream(void);
	~WinAmpSndStream(void);
	virtual BOOL	OpenStream(CString strFileName);
	virtual DWORD	Read(PBYTE pbData,DWORD dwNumBytes);
	virtual BOOL	CloseStream();
	virtual LONG	Seek( LONG lOff, UINT nFrom );
	virtual void	Flush();
	virtual void	Pause();
	
	virtual DWORD	GetTotalTime();
	virtual DWORD	GetCurrentTime();
	virtual VOID	InfoBox( HWND hWnd );

	virtual DWORD	GetBitRate(void) {return m_dwBitRate;}
	virtual void	SetBitRate(DWORD nValue) {m_dwBitRate=nValue;}

	int		GetPercent() const {return m_nPercent;}
	int		GetBufferSize() const {return m_nBufferSize;}
	int		GetSampleRate() const {return m_nSampleRate;}
	int		GetChannels() const {return m_nChannels;}
	CString	GetFileExtention() const {return m_strFileExt;}
	CString	GetFileName() const {return m_strFileName;}
	BYTE*	GetModifyBuffer() const { return m_pModifyBuffer;}
	DWORD	GetModifyBufferSize() const { return m_dwModifyBufferSize;}
	int		GetBytesPerSample() const {return m_nBytesPerSample;}
	int		GetPeakValue() const {return m_nPeakValue;}

	void	SetPercent( int nValue ) { m_nPercent = nValue; }
	void	SetBufferSize( int nValue ) { m_nBufferSize = nValue; }
	void	SetSampleRate( int nValue ) { m_nSampleRate = nValue; }
	void	SetChannels( int nValue ) { m_nChannels = nValue; }
	void 	SetFileExtention( CString strValue ) { m_strFileExt=strValue; }
	void	SetFileName( CString strValue ) { m_strFileName=strValue; }
	void	SetStreamType( SNDSTREAMTYPES nValue ) { m_StreamType = nValue; }
	void	SetBytesPerSample( int nValue ) { m_nBytesPerSample = nValue;}

	void	InitWinAmpPlugins( HWND hWnd, CString strPath );
	void	DeInitWinAmpPlugins(  );

	void	WinampPlugInFinished();
	int		GetNumWinampPlugins();

	CString GetWinampPluginInfo( int i );
	CString GetWinampPluginFileName( int i );
	void WinampPluginAbout( int i, HWND hWnd );
	void WinampPluginConfigure( int i, HWND hWnd );
	CString GetWinampFileNameExt();

void WinampPluginInfoBox( LPSTR lpszFileName, HWND hWnd );

private:
	int		m_dwCurrentFilePos;
	int		m_dwTotalFileSize;
	SNDSTREAMTYPES m_StreamType;
	int		m_nBufferSize;
	int		m_nChannels;
	int		m_nSampleRate;
	int		m_nPercent;
	CString	m_strFileName;
	CString	m_strFileExt;
	BYTE*	m_pModifyBuffer;
	DWORD	m_dwModifyBufferSize;
	INT		m_nPeakValue;
	INT		m_nBytesPerSample;
	DWORD	m_dwBitRate;

	void	FlushFIFO( );

};

