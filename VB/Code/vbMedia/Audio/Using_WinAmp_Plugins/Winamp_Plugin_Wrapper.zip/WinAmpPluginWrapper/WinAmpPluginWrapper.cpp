// WinAmpPluginWrapper.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "WinAmpPluginWrapper.h"
#include "WinAmpSndStream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

// CWinAmpPluginWrapperApp

BEGIN_MESSAGE_MAP(CWinAmpPluginWrapperApp, CWinApp)
END_MESSAGE_MAP()


// CWinAmpPluginWrapperApp construction

CWinAmpPluginWrapperApp::CWinAmpPluginWrapperApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CWinAmpPluginWrapperApp object
CWinAmpPluginWrapperApp theApp;

// Sound stream
WinAmpSndStream* sndStream;


// CWinAmpPluginWrapperApp initialization

BOOL CWinAmpPluginWrapperApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}

extern "C" int PASCAL EXPORT Initialise(HWND hWnd, LPCSTR strPath)
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   sndStream = new WinAmpSndStream();
   sndStream->InitWinAmpPlugins(hWnd, strPath);
   return sndStream->GetNumWinampPlugins();
}

extern "C" int PASCAL EXPORT GetPluginCount()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return sndStream->GetNumWinampPlugins();
}

extern "C" int PASCAL EXPORT GetTrackTotalTime()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return sndStream->GetTotalTime();
}

extern "C" int PASCAL EXPORT GetTrackCurrentTime()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return sndStream->GetCurrentTime();
}

extern "C" LONG PASCAL EXPORT Seek(LONG lOff, UINT nFrom )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return sndStream->Seek(lOff, nFrom);
}

extern "C" void PASCAL EXPORT CleanUp()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   sndStream->CloseStream();
   sndStream->DeInitWinAmpPlugins();
}

extern "C" BOOL PASCAL EXPORT OpenStream(LPCSTR strPath)
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->OpenStream(strPath);   
}

extern "C" BOOL PASCAL EXPORT CloseStream()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->CloseStream();
}

extern "C" DWORD PASCAL EXPORT Read(PBYTE pbData, DWORD dwNumBytes)
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->Read(pbData, dwNumBytes);
}

extern "C" DWORD PASCAL EXPORT GetBufferSize()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->GetBufferSize();
}

extern "C" int PASCAL EXPORT GetPercent()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->GetPercent();
}

extern "C" int PASCAL EXPORT GetSampleRate()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->GetSampleRate();
}

extern "C" int PASCAL EXPORT GetChannels()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->GetChannels();
}

extern "C" int PASCAL EXPORT GetBytesPerSample()
{
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   return sndStream->GetBytesPerSample();
}