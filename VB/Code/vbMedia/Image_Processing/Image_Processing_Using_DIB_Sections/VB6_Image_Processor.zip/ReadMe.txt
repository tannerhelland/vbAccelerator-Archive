***********************************************************************
vbAccelerator Image Processing Sample
Copyright � 1998-2002 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	            http://vbaccelerator.com
***********************************************************************

About the vbAccelerator Image Processing Sample
This sample demonstrates a VB 24 bit image processor using the DIB 
Section GDI object.

What you can do with this sample: 

* Image Processing 
	- Blurring and softening 
	- Sharpening 
	- Embossing 
	- Customised filters 
	- Minimum, Maximum and Average Rank filters for 
          impressionistic effects 
* Colour Manipulation 
	- Colourise images 
	- Darken and Light images 
	- Gray scale images 
	- Floyd Stucci Black and White conversion 
	- Decrease colour depth by dithering and matching to a 
          specified palette. 
* Image Combination 
	- Add, subtract with offsets or take the darkest/lightest pixels 
* Resample Images 
	- Use interpolation to create a smooth resized version of 
          an image. 

Any bugs or problems should be reported to the author 
(steve@vbaccelerator.com) for incorporation into future releases.

Installation Requirements
This sample requires Visual Basic 6 with at least Service Pack 4
applied.


**********************************************************************

vbAccelerator Software License
Version 1.0
Copyright (c) 2002 vbAccelerator.com

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are 
met:

1. Redistributions of source code must retain the above copyright 
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer 
   in the documentation and/or other materials provided with the 
   distribution.

3. The end-user documentation included with the redistribution, if 
   any, must include the following acknowledgment:

   "This product includes software developed by vbAccelerator 
    (http://vbaccelerator.com/)."

   Alternately, this acknowledgment may appear in the software 
   itself, if and wherever such third-party acknowledgments normally 
   appear.

4. The name "vbAccelerator" must not be used to endorse or promote 
   products derived from this software without prior written 
   permission. 

   For written permission, please contact vbAccelerator through 
   steve@vbaccelerator.com.

5. Products derived from this software may not be called 
   "vbAccelerator", nor may "vbAccelerator" appear in their name, 
   without prior written permission of vbAccelerator.

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL VBACCELERATOR OR ITS CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------


This software consists of voluntary contributions made by many 
individuals on behalf of the vbAccelerator. For more information, 
please see <http://vbaccelerator.com/>.


The vbAccelerator licence is based on the Apache Software Foundation 
Software Licence, Copyright (c) 2000 The Apache Software Foundation. 
All rights reserved.

***********************************************************************
