***********************************************************************
vbAccelerator ODCboLst Control Demonstration Project (odcldp.zip)
Copyright � 1998 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

About ODCboLst
Owner draw combo and list boxes are an excellent way to improve the 
look and feel of your application. However, there is precious little 
support for them in Visual Basic. The only owner-draw combo box supplied 
is the Checked list box style, but this is a preset list box style with 
no possibility for customisation. ODCbolst is  a new control, completely 
written in Visual Basic 5, which does all the hard work of setting up 
an owner draw combo or list box. 

It also provides some great looking preset implementations: 

+ Choosing colours 
+ Choosing system colours 
+ Choosing fonts 
+ Drawing combo or list boxes with icons, indentations and different font 
  and fore/back colours for each item 
+ Selecting paragraph styles, similar to the paragraph picker in Word 97 


This project contains a demonstration of the cPopMenu control, showing
it operating in most of the possible modes.  A companion project which
demonstrates how to create Client Draw combo and list boxes to 
implement Line style and texture pickers is also available (odclod.zip).

Installation Requirements
This demonstration requires Visual Basic 5 with at least Service Pack 
2 applied, the ODCboLst control (ODCboLst.OCX) and SSubTmr.DLL 
(available from www.dogma.demon.co.uk).

**********************************************************************
Distribution notice:
You are free to distribute odcldp.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).

If you wish to distribute odcldp.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
