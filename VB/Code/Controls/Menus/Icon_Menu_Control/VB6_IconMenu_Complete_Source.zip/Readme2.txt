***********************************************************************
vbAccelerator cPopMenu Control Demonstration Project (cpopmnus6.zip)
Copyright � 1998-2001 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com/
***********************************************************************

About cPopMenu
The cPopMenu control is a really simple way to get icons into a VB 
project's menus. It also allows you to create arbitrary new submenus, 
gives you control over the system menu and has some useful new events 
indicating when menu items are highlighted and exited.

This project contains a demonstration of the cPopMenu control, showing
it operating on multiple forms and in an MDI form.  All the functions
are exercised in this demo.

Installation Requirements
This demonstration requires Visual Basic 6 with at least Service Pack 
3 applied, the cPopMenu6 control (cPopMenu6.OCX) and SSubTmr6.DLL 
(available from http://vbaccelerator.com/).

**********************************************************************
Distribution notice:
You are free to distribute cpopmnus.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).

If you wish to distribute cpopmnus.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
