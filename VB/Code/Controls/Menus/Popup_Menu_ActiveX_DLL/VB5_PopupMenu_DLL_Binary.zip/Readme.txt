***********************************************************************
vbAccelerator Popup Menu Component
Copyright � 1998-1999 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com
***********************************************************************

This zip provides an all VB ActiveX in process DLL which can
create an unlimited number of popup menus, all with full icon support.
No longer do you need a form with menus on to get a Popup menu!  Not
just that but you can create as many menus as you want without 
needing a root VB menu, and each menu you create can have unlimited
sub menus.

This ZIP contains full source code for the DLL and the DLL itself.

**********************************************************************
Distribution notice:
You are free to distribute cnewmenu.zip in it's original state to any
public www site, online service or BBS without explicitly obtaining
the author's permission. (Notification would be greatly appreciated
though!).

You are free to modify the code for your own use as you wish.  However
do not distribute modified versions of cNewMenu.DLL under the same
filename in any form.  Please report any bugs in the component to the
author.

If you wish to distribute cnewmenu.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
