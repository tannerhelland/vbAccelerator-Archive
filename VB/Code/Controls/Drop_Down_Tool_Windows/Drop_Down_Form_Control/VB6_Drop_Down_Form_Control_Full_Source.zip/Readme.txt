***********************************************************************
vbAccelerator Drop-Down Form Control
Copyright � 1998 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com/
***********************************************************************

About the Drop-Down Form Control
This control allows to create drop-down tool windows which the user
can drag off and float like the colour picker provided with Microsoft
Office.

In addition, it also provides a titlebar modifier which ensures that 
your application's main form gets and keeps the focus regardless of
whether a tool window takes the input focus, making your app look and
behave in a more professional manner.

Any bugs or problems should be reported to the author 
(steve@vbaccelerator.com) for incorporation into future releases.

Installation Requirements
The control requires Visual Basic 5 with at least Service Pack 2 applied
and SSubTmr.DLL (available from http://vbaccelerator.com/)

**********************************************************************
Distribution notice:
You are free to distribute this zip in it's _original_ state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled OCX file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute this zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
