***********************************************************************
vbAccelerator S-Grid Component
Copyright � 1999 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
  Visit vbAccelerator - free, advanced source code for VB programmers
	             http://vbaccelerator.com
***********************************************************************

S-Grid is an all VB grid giving you the control other grids don't, and 
all in 260kb. Create Outlook-style grids, span column text across rows, 
freely set row and column heights, set colours and fonts for each cell, 
add icons to cells, sort and group data... 

This ZIP contains the release version of the OCX for VB5.

Dependencies
============
S-Grid requires SSubTmr.DLL to run. Download it from:
http://vbaccelerator.com/j-index.htm?url=codelib/ssubtmr/ssubtmr.htm

**********************************************************************
Distribution notice:
You are free to distribute sgridctl.zip in it's original state to any
public www site, online service or BBS without explicitly obtaining
the author's permission. (Notification would be greatly appreciated
though!).

You are free to use and distribute vbalGrid.ocx unmodified in your
projects.

If you wish to distribute sgridctl.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.

Please report any bugs in the component to the author.
***********************************************************************
