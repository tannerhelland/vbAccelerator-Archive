// Avoid libc dependency (or write your own stackchecker?)
#pragma check_stack(off)
#pragma comment(linker,"/NODEFAULTLIB")

// In VStudio 6, it is also necessary to omit /GZ from the compiler line
// or else calls to __chkesp are generated.


// Declare our payload functions according to the warped VB methods
class Helpers
{
private:
	void __stdcall Helpers::LOWORD (  );
	void __stdcall Helpers::HIWORD (  );
};
// Yes, we need to declare this class and private member functions
// and a void return type and a void parameter list, or else we'll
// not get the same name decoration as VB uses, and the linker will
// not link the calls to this code. Ask the VB developers why they
// lie.

// Due to these lies, both getting at the parameters and getting
// a return value into EAX is a problem.

#if 0
// This code precludes C optimizations by using asm to access the
// arguments, but, hey, it's only the very first working sample!
void __stdcall Helpers::LOWORD (  )
{
	int iIn;
	int iOut;

	_asm {
		mov		eax,[ebp+8]
		mov		iIn, eax
	}

	iOut = (unsigned short)(iIn);

	_asm {
		mov		eax, iOut
	}
}

void __stdcall Helpers::HIWORD (  )
{
	int iIn;
	int iOut;

	_asm {
		mov		eax,[ebp+8]
		mov		iIn, eax
	}

	iOut = (unsigned short)((unsigned long)iIn >> 16);

	_asm {
		mov		eax, iOut
	}
}
#elif 0
// - use the this pointer. C++ thinks there is a pointer on the stack
// this is the locations where the actual parameters begin. Pity
// that we can't take the adress of the this pointer. I also could
// not think of a non-_asm-using way to put the result into eax.
typedef char *  vba_list;
#define _INTSIZEOF(n)   ( (sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1) )
#define vba_start(ap)  ( ap = (vba_list)&(this) )
#define vba_arg(ap,t)    ( *(t *)((ap += _INTSIZEOF(t)) - _INTSIZEOF(t)) )
#define vba_end(ap)      ( ap = (vba_list)0 )

void __stdcall Helpers::LOWORD (  )
{
	vba_list va;
	vba_start (va);
	return vba_arg(va,unsigned long) & 0xFFFFUL;
}

void __stdcall Helpers::HIWORD (  )
{
	vba_list va;
	vba_start (va);
	return vba_arg(va,unsigned long) >> 16;
}
#else
// - IF using __asm, drop the function prolog.
__declspec(naked) void __stdcall Helpers::LOWORD (  )
{
	_asm {
		mov		eax,[esp+4]
		and		eax,0FFFFh
		ret		4
	}
}

__declspec(naked) void __stdcall Helpers::HIWORD (  )
{
	_asm {
		mov		eax,[esp+4]
		shr		eax,16
		ret		4
	}
}
#endif
