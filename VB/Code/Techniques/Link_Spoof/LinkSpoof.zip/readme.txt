
                                LinkSpoof


A slimy hack to get C++ or assembler code linked into an executable 
created by Visual Basic v6.0

'***********************************************************************
'*         Copyright �1999 Robert Heinig, All Rights Reserved          *
'*                         mailto:rheinig@gmx.net                      *
'***********************************************************************
'* You are free to use this tool within your own applications, but you *
'* are expressly forbidden from selling or otherwise distributing this *
'* source code without prior written consent. Free distribution of     *
'* this tool is only allowed in form of its original, unmodified ZIP   *
'* file, including the executable, the source, the readme and the      *
'* sample program. Additionally, distribution must not charge any fee. *
'***********************************************************************



How to get going:
Locate your VB installation directory. It should contain VB6.EXE and
LINK.EXE. Rename LINK.EXE to LINK0.EXE and copy LINK.EXE (the LinkSpoof 
tool) from this archive into the directory.
Installation is now complete, operation should be 100% transparent 
unless you create a file named LinkSpoof.inf in any directory that 
contains object or library files during a VB build.
In case you're worried, compile one of your existing projects to verify
its build is not affected.
Now unpack the Test project and look at the source. Notice that it has
two boring functions in Helpers.bas. Run it from the IDE - nothing 
special. Now take a look at LinkSpoof.inf: It specifies that an EXE build
should ignore the output from Helpers.bas and use HelpersC.obj instead.
If you own VC++6, you can open the provided EXE, open frmMain.frm, open
HelpersC.cpp, set breakpoints and actually see that the inline code from
HelpersC is used. Switch to disassembly view to get that hardcode hacker
feeling. You can recompile this project, a linker log and a map file are
generated for your late-night reading pleasure. With C++, you can recompile
HelpersC as well, just do not use the Build Project functions, do only a
single-file compile. HelpersC.obj is all you want. Take another look at
LinkSpoof.inf to see why the map file is generated and why the Linker log
is verbose. Lastly, read LinkSpoofSample.inf for an explanation of the
supported features of the control file. Set ShowCmd to 1 and recompile the
test project. While the message box shows the command line VB usually
passes to the linker, make a dumpbin of Helpers.OBJ to learn how to
find out the names you need to give your replacement functions. Be
creative...


If you have some substantial question or want to contribute an improvement
(that is, if you think that that which you want to adress is a result from
you being cleverer than me), feel free to contact me but expect no normal
response time from the given email adress.


Have fun,
    Robert Heinig



DISCLAIMER

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE DISTRIBUTED "AS IS" AND WITHOUT
WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES
WHETHER EXPRESSED OR IMPLIED. NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE
IS OFFERED.
Good data processing procedure dictates that any program using this toolkit
be thoroughly tested with non-critical data before relying on it. THE USER
MUST ASSUME THE ENTIRE RISK OF USING THE TOOLKIT.

