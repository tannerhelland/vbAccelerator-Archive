I wrote this cool compression code module that is an interface to the zLib.DLL compression library. It is used for in-memory compression. Using file IO in Visual Basic you can also achieve file compression too.

To use this project in Visual Basic:

Simply place the ZLIB.DLL file into the common Windows system
directory.

If using NT, place it into your WinNT\System32 directory.
(The \system32 directory is on NT, the \system directory is on Win95)
(ie, C:\WINDOWS\SYSTEM)

Then just run the VBG file. This file contains both the control
source project and the demonstration project. Also, there is a class that I

(the ZLIB.DLL is written by the zLib authors - it is a C DLL)

I wrote the interface and some helper stuff, so that VB programmers
can make use of it.

It's free! Feel free to modify the source. Change it if you wish, and
incorporate it into your own applications.

It's free and doesn't cost a cent. Anyone can write cool compression with VB now.

They'll quit spending huge money on compression tools just to use an in-memory compression interface. Now it's there for free and for all to see and use. Comes with complete source code. The source code was written in VB6 but it can also be used in VB5 too.

:-)

Benjamin Dowse