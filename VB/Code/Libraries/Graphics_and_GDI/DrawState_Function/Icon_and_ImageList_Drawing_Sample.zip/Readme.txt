***********************************************************************
vbAccelerator Icon Processing Sample
Copyright � 1998 Steve McMahon
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

This sample demonstrates how to draw disabled, colourised and
dithered icons with the DrawState GDI call.  It also shows
how to use the ImageList API to extract icons and customise
drawing selected icons.

**********************************************************************
Distribution notice:
You are free to distribute iconproc.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).

If you wish to distribute iconproc.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
