***********************************************************************
vbAccelerator HitTesting Sample (hittest.zip)
Copyright � 1998 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

About the vbAccelerator Hit Testing Sample
This subclassing sample provides code demonstrating how to reliably
modify the behaviour of a VB form so that parts of it behave like title 
bars and resize borders. You can use this code to: 

* Create windows without a title bar that you can click on 
  anywhere to move around 
* Build fake title bars 
* Add a Resize Gripper box to the lower right-hand corner. 

Any bugs or problems should be reported to the author 
(steve@dogma.demon.co.uk) for incorporation into future releases.

Installation Requirements
vbalTbar requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from www.dogma.demon.co.uk)

**********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled vbalHitT.dll file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute the source by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
