Name:     vbAccelerator SSubTmr object
          SubClass.cls
Author:   Marzo Sette Torres Junior (marzojr@taskmail.com.br)
Date:     12 February 2004

Strongly based on the original vbAccelerator SSubTmr object
by Steve McMahon (steve@vbaccelerator.com)

Borrows heavily on code by Paul Caton, available for free at
http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51403&lngWId=1
(you need to register, but it is free)

Most of this class module was moved from the (outdated) SubClass.bas
The exception is in the following functions/subs/properties:
      AddrFunc, CurrentMessage, InIDE/SetTrue, PatchRel, PatchVal
      Class_Initialize, Class_Terminate
Of these functions, InIDE/SetTrue are "general knowledge" in VB;
AddrFunc, although not as known as InIDE/SetTrue, is also "out",
being used mainly to call CDECL functions from VB. Despite that,
the specific form in which they appear here is due Paul Caton.

Class_Initialize, Class_Terminate, PatchRel and PatchVal are all
essentially what Paul Caton wrote - the exception is that the
ASM snippet (the *really* *really* long hex string) is my
translation into ASM of the original SSubTmr WindowProc, by
Steve McMahon. However, I must still give credit to Paul Caton
because the ASM snippet borrows a few ideas from his subclassing code.

Requires: None

Donated to vbAccelerator

--------------------------------------------------------------------------------------

How to use this subclasser:
  Add a reference to the DLL. That's all.

  This component retains binary compatibility with the original
  vbAccelerator component; this way, all you have to do is
  unregister the old component and re-register the new one
  to use on all your projects - compiled or otherwise.

--------------------------------------------------------------------------------------

The implementation of the Subclassing part of the SSubTmr object.
Use this class module + ISubClass.Cls to replace dependency on the DLL.

History:
  14 February 2004
      The IDE detection has been reworked; as a result, there is no need
      to create project groups with the component.
  12 February 2004
      Finished being written.
