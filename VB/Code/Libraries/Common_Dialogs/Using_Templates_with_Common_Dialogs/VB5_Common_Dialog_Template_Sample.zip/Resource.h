//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WAdllgres.rc
//
#define DLG_ADDFILES                    1900
#define IDC_BUTTONPWD                   3010
#define IDC_BUTTONWILD                  1901
#define IDC_LBLACTION                   508
#define IDC_CBOACTION                   502
#define IDC_LBLCOMPRESS                 509
#define IDC_CBOCOMPRESS                 503
#define IDC_LBLSPAN                     511
#define IDC_CBOSPAN                     504
#define IDC_CHK83                       3006
#define IDC_GRPFOLDERS                  510
#define IDC_CHKSUBFLDR                  506
#define IDC_CHKEXTRAFLDR                507
#define IDC_GRPATTRS                    203
#define IDC_CHKINCARCHSET               3008
#define IDC_CHKRESETARCH                3009
#define IDC_CHKINCHIDSYS                3007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
