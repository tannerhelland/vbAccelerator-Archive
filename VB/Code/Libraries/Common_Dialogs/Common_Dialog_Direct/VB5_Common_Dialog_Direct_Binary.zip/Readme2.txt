***********************************************************************
vbAccelerator CommonDialog/Direct Component (cmdlgd.zip)
Copyright � 1998-1999 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com
***********************************************************************

About CommonDialog/Direct
Common Dialog/Direct is a new DLL or class library which shows how to 
completely replace COMDLG32.OCX through Visual Basic code. The main 
advantage of this is you no longer need to put a control on a form to 
use common dialogs - just declare an instance of the class and you have 
a straight replacement. 

Common Dialog/Direct improves upon the standard COMDLG32.OCX features
by additionally incorporating a Page Setup dialog box and also a Common
Dialog hooks, allowing you to centre common dialogs and verify selections
before the dialog is closed.

Installation Requirements
Common Dialog/Direct requires Visual Basic 5 with at least Service 
Pack 2.

**********************************************************************
Distribution notice:
You are free to distribute cmdlgd.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled cmdlgd.dll file.

If you wish to distribute cmdlgd.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
